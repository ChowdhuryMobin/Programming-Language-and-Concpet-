public static void getChar ()
{
  if (fileScanner.hasNext ())
    {
      nextChar = fileScanner.next ().charAt (0);
      if (Character.isLetter (nextChar))
	charClass = LETTER;
      else if (Character.isDigit (nextChar))
	charClass = DIGIT;
      else
	charClass = UNKNOWN;
    }
  else
    {
      charClass = EOF;
    }
}
