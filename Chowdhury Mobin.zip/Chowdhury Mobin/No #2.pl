$x = 1;
sub subfunc1
{
  return $x;
}
sub static
{
  my $x = 1;
  return subfunc1 ();
}

$y = 2;
sub subfunc2
{
  return $y;
}
sub dynamic
{
  local $y = 3;
  return subfunc2 ();
}

print "The static scope ", static (), "\n";

print "The dynamic scope ", dynamic (), "\n";
