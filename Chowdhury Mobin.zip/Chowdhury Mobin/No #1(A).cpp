#include <iostream>
using namespace std;
enum sports
{
  BASKETBALL = 1,
  FOOTBALL = 2,
  BASEBALL = 3,
  TENNIS = 4,
} play;
enum weekday
{ Sunday, Monday, Tuesday, Wednesday, Thursday, Friday, Saturday };
int
main ()
{
  play = BASEBALL;
  weekday w = Friday;
  if (w == Friday && play == BASEBALL)
    {
      cout << "Today is Friday, we have a BASEBALL match." << endl;
    }
  return 0;
}
