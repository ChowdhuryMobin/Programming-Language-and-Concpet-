#include<iostream>
using namespace std;
int
main ()
{
  int weekday[] = { 0, 1, 2, 3, 5, 6, 7 };
  int sports[] = { 1, 2, 3, 4 };
  int w = weekday[0];
  int s = sports[0];
  if (w == 0 && s == 1)
    {
      cout << "Today is Friday, we a have BASEBALL match." << endl;
    }
  return 0;
}
