#include<stdio.h>
int
main ()
{
  int a = 50, b = 20, c = 10;
  if (a > b > c)
    printf ("True\n");
  else
    printf ("False\n");
}
