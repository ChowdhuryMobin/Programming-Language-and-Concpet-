package ChowdhuryMobin;

public class Main
{
    public static void main (String[]args)
    {
        int [][] x = { {0, 0, 0}, {4, 5, 6}, {1, 1, 1} };
        int rowNum = 0;
        int n = x.length;
        for (int i = 0; i < n; i++)
        {
            for (int j = 0; j < n; j++)
            {
                if (x[i][j] != 0)
                {
                    break;
                }
                else if (j == n-1 && x[i][j] == 0)
                {
                    rowNum = i;
                    break;
                }
            }
        }
        System.out.println("First all-zero row is: " + (rowNum + 1));
    }

}
