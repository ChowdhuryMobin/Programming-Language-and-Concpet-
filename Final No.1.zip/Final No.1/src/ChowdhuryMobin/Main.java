package ChowdhuryMobin;

public class Main
{
    private static final String FinalExam = null;

    public static void main (String[] args)
    {

        int a = 101;
        int b = 0100;
        int c = 0xFace;
        int d = 0b1111;
        System.out.println(a);
        System.out.println(b);
        System.out.println(c);
        System.out.println(d);

        float aa = (float) 101.230;
        float bb = (float) 0123.222;

        System.out.println(aa);
        System.out.println(bb);

        String s = "FinalExam";
        String s1 = FinalExam;

        System.out.println(s);
        System.out.println(s1);

        int amount = 1000;
        int pin = 12345;
        int age = 22;

        System.out.println("The Amount is : " + amount);
        System.out.println("The Pin is : " + pin);
        System.out.println("The Age is : " + age);
    }
}
